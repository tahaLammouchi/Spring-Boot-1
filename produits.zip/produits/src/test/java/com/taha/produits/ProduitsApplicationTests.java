package com.taha.produits;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProduitsApplicationTests {

	@Test
	void contextLoads() {
	}

}
